LUMIO — телефонға орнату (Netlify, тегін)
1) Папканы GitHub-қа жүкте → app.netlify.com → Add new site → Import from Git.
2) Site settings → Environment variables: ANTHROPIC_API_KEY = Claude API кілтің (console.anthropic.com).
3) Deploy. Сайт сілтемесін телефонда Chrome-мен ашып: ⋮ → «Басты экранға қосу» (iPhone: Safari → Бөлісу → «На экран Домой»).
4) Play Market: pwabuilder.com → сайт сілтемесі → Android (AAB) → Google Play Console ($25 бір рет).
Назар: шексіз чат API шығынын көбейтеді — Anthropic консолінде айлық шек қой.
