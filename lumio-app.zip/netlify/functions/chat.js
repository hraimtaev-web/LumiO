// Lumio сервері. ANTHROPIC_API_KEY — тек Netlify орта айнымалысында.
const H={"Content-Type":"application/json"};
const R=(c,o)=>({statusCode:c,headers:H,body:JSON.stringify(o)});
const SYS="You are Lumio, a brilliant, friendly, all-knowing AI assistant. Answer in the user's language. Be accurate, complete and clear; use short paragraphs, lists and code blocks (```) when helpful. Never refuse harmless requests. Admit uncertainty instead of guessing.";
exports.handler=async(e)=>{
  if(e.httpMethod!=="POST")return R(405,{error:"POST only"});
  try{
    const {messages}=JSON.parse(e.body||"{}");
    if(!Array.isArray(messages)||!messages.length||messages.length>30)return R(400,{error:"bad"});
    const m=messages.map(x=>({role:x.role==="assistant"?"assistant":"user",content:String(x.content||"").slice(0,8000)}));
    if(m[0].role!=="user"||m[m.length-1].role!=="user")return R(400,{error:"bad order"});
    const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",
      headers:{"content-type":"application/json","x-api-key":process.env.ANTHROPIC_API_KEY,"anthropic-version":"2023-06-01"},
      body:JSON.stringify({model:"claude-haiku-5-5",max_tokens:2000,system:SYS,messages:m})});
    if(r.status===429)return R(429,{error:"rate"});
    const d=await r.json();
    if(!r.ok)return R(502,{error:"api"});
    return R(200,{text:(d.content||[]).map(c=>c.text||"").join("")});
  }catch(err){return R(500,{error:"server"})}
};
